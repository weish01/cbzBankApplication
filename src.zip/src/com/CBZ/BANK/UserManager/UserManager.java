package com.CBZ.BANK.UserManager;

import java.util.HashMap;
import java.util.Map;
import com.CBZ.BANK.service.SecurityUtil; // Correct import

public class UserManager {
    private Map<String, String> users; // username -> password
    private Map<String, UserProfile> userProfiles;

    public UserManager() {
        this.users = new HashMap<>();
        this.userProfiles = new HashMap<>();
        // Initialize with some default users if needed
    }

    // User registration
    public boolean registerUser(String username, String password, String email) {
        if (users.containsKey(username)) {
            return false; // User already exists
        }

        // Hash password before storing (use SecurityUtil)
        String hashedPassword = SecurityUtil.hashPassword(password);
        users.put(username, hashedPassword);
        userProfiles.put(username, new UserProfile(username, email));

        return true;
    }

    // User login validation
    public boolean validateLogin(String username, String password) {
        if (!users.containsKey(username)) {
            return false;
        }

        String storedHash = users.get(username);
        String inputHash = SecurityUtil.hashPassword(password);
        return inputHash.equals(storedHash);
    }

    // Get user profile
    public UserProfile getUserProfile(String username) {
        return userProfiles.get(username);
    }

    // Check if user exists
    public boolean userExists(String username) {
        return users.containsKey(username);
    }

    // Inner class for user profile
    public class UserProfile {
        private String username;
        private String email;
        private String fullName;
        private String phoneNumber;

        public UserProfile(String username, String email) {
            this.username = username;
            this.email = email;
        }

        // Getters and setters
        public String getUsername() { return username; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        public String getPhoneNumber() { return phoneNumber; }
        public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    }
}