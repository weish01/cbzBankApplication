package com.CBZ.BANK.User;

public class User {
    private String username;
    private String password;

    // Constructor
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getter for username
    public String getUsername() {
        return username;
    }

    // Getter for password
    public String getPassword() {
        return password;
    }

    // Setter for password (optional, if you want to allow password changes)
    public void setPassword(String newPassword) {
        this.password = newPassword;
    }

    // Display user information
    public void displayUserInfo() {
        System.out.println("Username: " + username);
    }
}
