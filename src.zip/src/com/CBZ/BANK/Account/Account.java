package com.CBZ.BANK.Account;

import com.CBZ.BANK.Transaction.TransactionRecord;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class Account {
    private String accountType;
    private String accountNumber;
    private String ownerName;
    private String ownerEmail;
    private String phoneNumber;
    private double balance;
    private String dateCreated;
    private List<TransactionRecord> transactions;
    private String oldBalance;

    // Default constructor with Sindisiwe Letter's details
    public Account() {
        this.accountType = "Savings Account";
        this.accountNumber = "1234567890";
        this.ownerName = "Sindisiwe Letter";
        this.ownerEmail = "lettercindy@gmail.com";
        this.phoneNumber = "0779995522";
        this.balance = 1500.0;
        this.dateCreated = new Date().toString();
        this.transactions = new ArrayList<>();


        TransactionRecord initialRecord = new TransactionRecord("Account Created", balance);
        transactions.add(initialRecord);
    }

    public void deposit(double amount) {
        if (amount > 0) {
            double oldBalance = balance;
            balance += amount;

            TransactionRecord record = new TransactionRecord("Deposit", amount);
            transactions.add(record);
            System.out.println("✓ Deposited: $" + amount);
            System.out.println("  Previous Balance: $" + oldBalance);
            System.out.println("  New Balance: $" + balance);
        } else {
            System.out.println("✗ Invalid deposit amount!");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            // FIXED: Only 2 arguments
            TransactionRecord record = new TransactionRecord("Withdraw", amount);
            transactions.add(record);
            System.out.println("✓ Withdrew: $" + amount);
            System.out.println("  Previous Balance: $" + oldBalance);
            System.out.println("  New Balance: $" + balance);
        } else if (amount > balance) {
            System.out.println("✗ Insufficient funds!");
            System.out.println("  Current Balance: $" + balance);
            System.out.println("  Attempted Withdrawal: $" + amount);
        } else {
            System.out.println("✗ Invalid withdrawal amount!");
        }
    }

    public void checkBalance() {
        System.out.println("\n=== ACCOUNT BALANCE ===");
        System.out.println("Current Balance: $" + balance);
        System.out.println("=======================");

        // FIXED: Only 2 arguments
        TransactionRecord balanceCheck = new TransactionRecord("Balance Check", 0);
        transactions.add(balanceCheck);
    }

    public void displayAccountInfo() {
        System.out.println("\n=== ACCOUNT INFORMATION ===");
        System.out.println("Account Type: " + accountType);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Owner Name: " + ownerName);
        System.out.println("Owner Email: " + ownerEmail);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Balance: $" + balance);
        System.out.println("Date Created: " + dateCreated);
        System.out.println("Total Transactions: " + transactions.size());
        System.out.println("===========================");
    }

    public void showTransactionHistory() {
        System.out.println("\n=== TRANSACTION HISTORY ===");
        if (transactions.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            for (int i = 0; i < transactions.size(); i++) {
                System.out.print((i + 1) + ". ");
                transactions.get(i).displayTransaction();
            }
        }
        System.out.println("===========================");
    }

    // Getters
    public String getAccountType() { return accountType; }
    public String getAccountNumber() { return accountNumber; }
    public String getOwnerName() { return ownerName; }
    public String getOwnerEmail() { return ownerEmail; }
    public String getPhoneNumber() { return phoneNumber; }
    public double getBalance() { return balance; }
    public String getDateCreated() { return dateCreated; }
    public List<TransactionRecord> getTransactions() { return transactions; }

    // Setters for profile updates - FIXED: Typo in setPhoneNumber
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public void setOwnerEmail(String ownerEmail) { this.ownerEmail = ownerEmail; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; } // Fixed typo: pnoneNumber → phoneNumber
}