package com.CBZ.BANK.main;

public class UserManager {
    public void getClass(String regUser, String regPass) {

    }
}
