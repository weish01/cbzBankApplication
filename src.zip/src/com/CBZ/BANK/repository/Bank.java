package com.CBZ.BANK.repository;

import com.CBZ.BANK.Account.Account;

public class Bank {
    public static void main(String[] args) {
        Account acc = new Account();
        acc.displayAccountInfo();

        System.out.println("\n--- Performing Transactions ---");
        acc.checkBalance();
        acc.deposit(200);
        acc.withdraw(50);
        acc.checkBalance();
        acc.showTransactionHistory();
    }
}