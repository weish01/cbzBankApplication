package com.CBZ.BANK.Transaction;

import java.util.Date;

public class TransactionRecord {
    private String transactionType;
    private double amount;
    private String timestamp;

    // FIXED: Constructor with only 2 arguments
    public TransactionRecord(String transactionType, double amount) {
        this.transactionType = transactionType;
        this.amount = amount;
        this.timestamp = new Date().toString();
    }

    public void displayTransaction() {
        switch (transactionType) {
            case "Account Created":
                System.out.printf("ACCOUNT CREATED - Initial Balance: $%.2f (%s)%n", amount, timestamp);
                break;
            case "Balance Check":
                System.out.printf("BALANCE CHECK - Balance: $%.2f (%s)%n", amount, timestamp);
                break;
            case "Deposit":
                System.out.printf("DEPOSIT: +$%.2f (%s)%n", amount, timestamp);
                break;
            case "Withdraw":
                System.out.printf("WITHDRAWAL: -$%.2f (%s)%n", amount, timestamp);
                break;
            default:
                System.out.printf("%s: $%.2f (%s)%n", transactionType, amount, timestamp);
        }
    }

    // Getters
    public String getTransactionType() { return transactionType; }
    public double getAmount() { return amount; }
    public String getTimestamp() { return timestamp; }
}